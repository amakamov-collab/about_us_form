# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models



class Coutries(models.Model):
    coutries_id = models.TextField(primary_key=True)
    coutries_name = models.TextField()
    region = models.TextField()

    class Meta:
        managed = False
        db_table = 'coutries'


class Department(models.Model):
    department_id = models.TextField(primary_key=True)
    department_name = models.TextField()
    location = models.TextField()

    class Meta:
        managed = False
        db_table = 'department'
class Dependent(models.Model):
    dependent_id = models.TextField(primary_key=True)
    first_name = models.TextField()
    last_name = models.TextField()
    relationship = models.TextField()
    employee = models.ForeignKey('Employee',models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'dependent'

class Employee(models.Model):
    employee_id = models.TextField(primary_key=True)
    first_name = models.TextField(blank=True, null=True)
    last_name = models.TextField()
    email = models.TextField()
    phone = models.TextField(blank=True, null=True)
    hire_date = models.TextField()
    job = models.ForeignKey('Job',models.DO_NOTHING)
    salary = models.TextField()# This filed type is a guess
    department = models.ForeignKey('Department',models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'employee'
class Job(models.Model):
    job_id = models.TextField(primary_key=True)
    job_title = models.TextField()
    min_salary = models.TextField()# This filed type is a guess
    max_salary = models.TextField()# This filed type is a guess

    class Meta:
        managed = False
        db_table = 'job'

class Location(models.Model):
    location_id = models.TextField(primary_key=True)
    street_adress= models.TextField(blank=True, null=True)
    postal_code = models.TextField(blank=True, null=True)
    city = models.TextField()
    state = models.TextField(blank=True, null=True)
    country = models.ForeignKey('Country',models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'location'

class Region(models.Model):
    region_id = models.TextField(primary_key=True)
    region_name = models.TextField()

    class Meta:
        managed = False
        db_table = 'region'






from django.http import HttpResponse
from django.shortcuts import render
from .models import Post


# Create your views here.

def blog_list(request):
    posts = Post.objects.all()
    posts_list = []
    for post in posts:
        post_list += f"<li>{post.title}</li>"
    return HttpResponse(f"<ol>{posts_list}</ol>")


from django.shortcuts import render
from .models import Countries, Employees
from django.http import HttpResponse
from django.db.models import Q

def orm_list(request):
    queryset = Employees.objects.filter(Q(first_name_startswith= 'R')|Q(last_name_startswith= 'D'))
    print(queryset.query)
    e = Employees.objects.get(id=1).\
    e.update(
        first_name= 'John',

    )
    e.save()
    emp_list = ""
    for c in queryset:

        emp_list += f"<li>{c.fir}</li>"
    return HttpResponse(f"<ol>{emp_list}</ol>")

