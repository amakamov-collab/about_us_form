# dars- 43 Xasanboeva Nigina
# "B3" GURUHI Fronted asoslari

# <html>
# <body>
#
# <h1>My First Heading</h1>
#
# <p>My first paragraph.</p>
#
# </body>
# </html>
# Frontend — bu veb-saytning foydalanuvchi ko‘radigan qismi. Saytdagi tugmalar, ranglar, rasmlar, animatsiyalar — barchasi frontend bilan yaratiladi.
#
# Frontendning 3 asosiy tili bor:
#
# 1.HTML — skelet (tuzilma)
#
# 2.CSS — dizayn (ko‘rinish)
#
# 3.JavaScript — harakat (interaktivlik)
#  3. JavaScript
#
#  Saytga jon bag‘ishlaydi: tugma bosilganda nimadir bo‘lsa, animatsiyalar, hisob-kitoblar — barchasi JS.
#
# Misol:
# document.getElementById("btn").onclick = function() {
#     alert("Bosding!");
# }
#
# JavaScript nima qila oladi?
#
# Tugmalarni boshqaradi
#
# Formani tekshiradi (login, login)
#
# Server bilan aloqa qiladi (API)
#
# Animatsiya yaratadi
#
# O‘yinlar, botlar, web-applar yaratadi
#
#Frontend asoslari (juda muhim)



#  1.HTML + CSS joylashuv (layout)
#
# Flexbox
#
# Grid
#
#  Responsive dizayn
#
# Media queries
#
# Mobilga moslashgan dizayn
#
#  2.JavaScript asoslari
#
# Variables (let, const)
#
# Functions
#
# Events
#
# DOM manipulyatsiya
#
# Arrays & Objects
#
# 3.GitHub va VS Code bilan ishlash
#
# Bu frontendchilar uchun asosiy ish muhiti.
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
