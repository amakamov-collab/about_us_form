 # dars_38 Xasanboeva Nigina  Soft skills, Fast food dastavka boti

# STATES = {
#     "reg": 1,
#     "menu": 2
# }
#
#
# WELCOME_TEXT = "Xush kelibsiz / Добро пожаловать!"
# CHOOSE_LANG = "Tilni tanlang / Выберите язык!"
# BTN_LANG_UZ = "Uzbek tili"
# BTN_LANG_RU = "Русский язык"
# TEXT_LANG_WARNING = "Iltimos tillardan birini tanlang!\nПожалуйста, выберите один из языков!"
#
#
# TEXT_ENTER_FIRST_NAME = {
#     1: "Iltimos ismingizni kiriting!",
#     2: "Пожалуйста, введите ваше имя!"
# }
# TEXT_ENTER_LAST_NAME = {
#     1: "Iltimos familiyangizni kiriting!",
#     2: "Пожалуйста, введите свою фамилию!"
# }
# BTN_SEND_CONTACT = {
#     1: "Yuborish",
#     2: "Отправить"
# }
# TEXT_ENTER_CONTACT = {
#     1: "Iltimos telefon raqamingizni yuboring yoki <<Yuborish>> tugmasini bosing!",
#     2: "Отправьте свой номер телефона или нажмите кнопку <<Отправить>>!"
# }
# TEXT_MAIN_MENU = {
#     1: "Asosiy menyu",
#     2: "Главное меню"
# }



# from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, MessageHandler, Filters, ConversationHandler
# from database import Database
# from register import check
# from messages import message_handler
# ADMIN_ID = 000000000000
# TOKEN = ""
#
# db = Database("db-evos.db")
#
#
# def start_handler(update, context):
#     check(update, context)
#
#
# def inline_handler(update, context):
#     query = update.callback_query
#     data_sp = str(query.data).split("_")
#
# def contact_handler(update, context):
#     message = update.message.contact.phone_number
#     user = update.message.from_user
#     # db_user = db.get_user_by_chat_id(user.id)
#     db.update_user_data(user.id, "phone_number",message)
#     check(update,context)
#
# def main():
#     updater = Updater(TOKEN)
#     dispatcher = updater.dispatcher
#
#     dispatcher.add_handler(CommandHandler('start', start_handler))
#     dispatcher.add_handler(MessageHandler(Filters.text, message_handler))
#     dispatcher.add_handler(MessageHandler(Filters.contact, contact_handler))
#     dispatcher.add_handler(CallbackQueryHandler(inline_handler))
#
#     updater.start_polling()
#     updater.idle()
#
#
# if __name__ == '__main__':
#     main()



# import sqlite3
#
#
# class Database:
#     def __init__(self, db_name):
#         self.conn = sqlite3.connect(db_name, check_same_thread=False)
#         self.cur = self.conn.cursor()
#
#     def create_user(self, chat_id):
#         self.cur.execute("""insert into user(chat_id) values (?)""", (chat_id,))
#         self.conn.commit()
#
#     def update_user_data(self, chat_id, key, value):
#         self.cur.execute(f"""update user set {key} = ? where chat_id = ?""", (value, chat_id))
#         self.conn.commit()
#
#     def get_user_by_chat_id(self, chat_id):
#         self.cur.execute("""select * from user where chat_id = ?""", (chat_id, ))
#         user = dict_fetchone(self.cur)
#         return user
#
#
# def dict_fetchall(cursor):
#     columns = [col[0] for col in cursor.description]
#     return [
#         dict(zip(columns, row))
#         for row in cursor.fetchall()
#     ]
#
#
# def dict_fetchone(cursor):
#     row = cursor.fetchone()
#     if row is None:
#         return False
#     columns = [col[0] for col in cursor.description]
#     return dict(zip(columns, row))


# from register import check, check_data_decorator
# from database import Database
# import globals
# from telegram import KeyboardButton
#
# db = Database("db-evos.db")
#
#
# @check_data_decorator
# def message_handler(update, context):
#     message = update.message.text
#     user = update.message.from_user
#     state = context.user_data.get("state", 0)
#
#     if state == 0:
#         check(update, context)
#
#     elif state == 1:
#         db_user = db.get_user_by_chat_id(user.id)
#
#         if not db_user["lang_id"]:
#
#             if message == globals.BTN_LANG_UZ:
#                 db.update_user_data(user.id, "lang_id", 1)
#                 check(update, context)
#
#             elif message == globals.BTN_LANG_RU:
#                 db.update_user_data(user.id, "lang_id", 2)
#                 check(update, context)
#
#             else:
#                 update.message.reply_text(
#                     text=globals.TEXT_LANG_WARNING
#                 )
#
#         elif not db_user["first_name"]:
#             db.update_user_data(user.id, "first_name", message)
#             check(update, context)
#
#         elif not db_user["last_name"]:
#             db.update_user_data(user.id, "last_name", message)
#             buttons = [
#                 [KeyboardButton(text=globals.BTN_SEND_CONTACT[db_user['lang_id']], request_contact=True)]
#             ]
#             check(update, context)
#
#         elif not db_user["phone_number"]:
#             db.update_user_data(user.id, "phone_number", message)
#             check(update, context)
#
#         else:
#             check(update, context)
#
#     else:
#         update.message.reply_text("Salom")
