# Xasanbaeva Nigina 37 dars
# TOKEN = "5275283210:AAFM5JGvnW6uD6zDKz1-22UwXZ2jzkANR_k"
# DATA_BASE = "sample-database.db"
#
# from send_buttons import send_countries,send_regions
# from database import Database
# db = Database("sample-database.db")
#
# def inline_handler(update, context):
#     query = update.callback_query
#     print(query.data)
#     data_sp = str(query.data).split("_")
#     if data_sp[0] == "region":
#         if data_sp[1].isdigit():
#             countries = db.get_countries_by_region(int(data_sp[1]))
#             send_countries(context=context, countries=countries, chat_id=query.message.chat_id,
#                            message_id=query.message.message_id)
#
#         elif data_sp[1] == 'back':
#             regions = db.get_all_regions()
#             send_regions(context=context, regions=regions, chat_id=query.message.chat_id,
#                          message_id=query.message.message_id)
#     #
#     # if data_sp[0] == "country":
#         pass
#     if data_sp[0] == 'close':
#         msg = query.message.edit_text(
#             text="time",
#             reply_markup=None,
#         )
#         context.bot.delete_message(chat_id=query.message.chat_id, message_id=msg.message_id)
# from telegram import InlineKeyboardButton, InlineKeyboardMarkup
#
#
# def send_countries(context, countries, chat_id, message_id=None):
#     buttons = []
#     for country in countries:
#         buttons.append(
#             [
#                 InlineKeyboardButton(
#                     text=f"{country['country_name']}",
#                     callback_data=f"country_{country['country_id']}")
#             ]
#         )
#     buttons.append([InlineKeyboardButton(text="Back", callback_data="region_back")])
#
#     if message_id:
#         context.bot.edit_message_text(
#             chat_id=chat_id,
#             message_id=message_id,
#             text="<b>Choose countries</b>",
#             reply_markup=InlineKeyboardMarkup(
#                 inline_keyboard=buttons
#             ),
#             parse_mode="HTML"
#         )
#     else:
#         context.bot.send_message(
#             chat_id=chat_id,
#             text="<b>Choose countries</b>",
#             reply_markup=InlineKeyboardMarkup(
#                 inline_keyboard=buttons
#             ),
#             parse_mode="HTML"
#         )
