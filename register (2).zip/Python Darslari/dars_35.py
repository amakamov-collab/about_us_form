
from geopy.geocoders import Nominatim
def get_location_name(latitude, longitude):
    geolocator = Nominatim(user_agent="my_app")
    location = geolocator.reverse(f"{latitude}, {longitude}")
    return location.address

print(get_location_name(41.360608, 69.55181))

#
# import random
# from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackQueryHandler
# from telegram import BotCommand, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton, BotCommand, InputMediaPhoto, ReplyKeyboardRemove
# ADMIN_ID = 392330197
# TOKEN = "6255255483:AAEGa_tglVQJK74IcUEGCOsfZkEoVzz74dI"
#
#
#
#
#
#
# buttons = [
#     [InlineKeyboardButton(text="Send Photo", callback_data="send_photo"),
#      InlineKeyboardButton(text="Send Document", callback_data="send_document"),
#      InlineKeyboardButton(text="Change Photo", callback_data="change_photo"),
#      ],
#         [InlineKeyboardButton(text="Send Media Group", callback_data="send_group")]
# ]
# def start_func(update, context):
#     # commands = [BotCommand(command='start', description="Botga start berish"),
#     #             BotCommand(command='info', description="Bot haqida ma'lumot"),
#     #             ]
#     # context.bot.set_my_commands(commands=commands)
#     update.message.reply_photo(
#         # photo=open('photos/hi_bot.jpg', 'rb'),
#         photo='https://picsum.photos/400/200',
#         caption="Hello!!!",
#         reply_markup=InlineKeyboardMarkup(buttons)
#     )
#
# def message_handler(update, context):
#     # context.user_data - har bir user uchun maxsus dict o'zgaruvchi
#     if context.user_data.get('matn'):
#         words = context.user_data['matn']
#     else:
#         words = []
#     words.append(update.message.text)
#     context.user_data['matn'] = words
#     print(f"{update.message.from_user.username}: {words}")
#
#
# def inline_messages(update, context):
#     query = update.callback_query
#     print(query)
#     if query.data == 'send_document':
#         query.message.reply_document(
#             document=open('register_bot.py'),
#             caption='1-dars',
#             reply_markup=InlineKeyboardMarkup(buttons)
#         )
#
#
#
#     elif query.data == 'send_photo':
#         query.message.reply_photo(
#             photo=f'https://picsum.photos/id/{random.randint(1,100)}/400/200',
#             caption='Random Photo',
#             reply_markup=InlineKeyboardMarkup(buttons)
#         )
#     elif query.data == 'change_photo':
#         query.message.edit_media(media=InputMediaPhoto(media=f'https://picsum.photos/id/{random.randint(1,100)}/400/200'))
#
#         query.message.edit_reply_markup(reply_markup=InlineKeyboardMarkup(buttons))
#
#     elif query.data == 'send_group':
#         query.message.reply_media_group(
#             media=[
#                 InputMediaPhoto(media=open('photos/programmist.png','rb')),
#                 InputMediaPhoto(media=f'https://picsum.photos/id/{random.randint(1, 100)}/400/200'),
#                 InputMediaPhoto(media=f'https://picsum.photos/id/{random.randint(20, 100)}/400/200')
#             ]
#         )
# def photo_handler(update, context):
#     file = update.message.photo[-1].file_id
#     obj = context.bot.get_file(file)
#     obj.download('photos/user_photo.jpg')
# updater = Updater(token=TOKEN)
# dispatcher = updater.dispatcher
# dispatcher.add_handler(CommandHandler('start',start_func))
# dispatcher.add_handler(CommandHandler('menu', show_menu ))
# dispatcher.add_handler(CommandHandler('video', send_video))
# dispatcher.add_handler(MessageHandler(Filters.text,message_handler))
# dispatcher.add_handler(MessageHandler(Filters.contact,contact_handler))
# dispatcher.add_handler(MessageHandler(Filters.location,location_handler))


# updater.start_polling()
# updater.idle()
#
# import logging
# from telegram import ReplyKeyboardMarkup, KeyboardButton
# from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, ConversationHandler
# import sqlite3
# from geo_name import get_location_name

# import logging
# logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
#
# conn = sqlite3.connect("users.db")
# c = conn.cursor()
#
# c.execute("""CREATE TABLE IF NOT EXISTS users
#             (phone_number TEXT PRIMARY KEY,
#             first_name TEXT,
#             last_name TEXT,
#             age INTEGER,
#             gender TEXT,
#             address TEXT,
#             latitude REAL,
#             longitude REAL
#             );
# """)
# conn.commit()
#
# def start(update, context):
#     reply_text = 'Salom!" telefon raqamingizni kiriting:'
#     reply_markup = ReplyKeyboardMarkup,([
#         [KeyboardButton(text="Telefon kontaktinngizni ulashing",request_contact=True)]
#     ], 'resize_keyboard=True,' one_time_keyboard=True)
#     context.bot.send_message(chat_id=update.effective_user.id, text=reply_text, reply_markup=reply_markup)
#     logging.info(f"user - {update.effective_user.id} started")
#     return 'PHONE_NUMDERS'
#
# def phone_number(update, context):
#     phone_number = update.message.contact.phone_number
#     context.user_data['phone_number'] = phone_number
#     update.message.reply_text('Rahmat! Ismingiz nima?')
#     return 'FIRST_NAME'




# def last_name(update, context):
#     phone_number = update.message.contact.phone_number
#     context.user_data['first_name'] = phone_number
#     update.message.reply_text('Rahmat!Familiyangiz nima?')
#     return 'LAST_NAME'

 #  def_last_name(update, context):
#     phone_number = update.message.contact.phone_number
#     context.user_data['last_name'] = phone_number
#     update.message.reply_text('Rahmat!Yoshingiz nichi?')
#     return 'Age'


 #  def age(update, context):
#     phone_number = update.message.contact.phone_number
#     context.user_data['age'] = phone_number
#     update.message.reply_text('Rahmat! Jismingiz: ayol/erkak?')
#     return 'Gender'

# def gender(update, context):
#     gender = update.message.text
#     context.user_data['gender'] = gender
#     reply_markup = ReplyKeyboardMarkup([
#         [KeyboardButton(text="lokatsiyanngizni ulashing", request_location=True)]
#     ], resize_keyboard=True, one_time_keyboard=True)
#     context.bot.send_message(chat_id=update.effective_user.id, text="lokatsiyanngizni ulashing:", reply_markup=reply_markup)
#     return 'GEOLOCATION'


#
# class Updater:
#     pass
#
#
# def main():
#     updater = Updater(token="6255255483:AAEGa_tglVQJK74IcUEGCOsfZkEoVzz74dI")
#     dispatdefcher = updater.dispatcher
#
#     conv_handler = ConversationHandler(
#         entry_points=[CommandHandler('start', start)],
#         states={
#             'PHONE_NUMBER': [MessageHandler(Filters.contact & ~Filters.command, phone_number)],
#             'FIRST_NAME': [MessageHandler(Filters.text & ~Filters.command, first_name)],
#             'LAST_NAME': [MessageHandler(Filters.text & ~Filters.command, last_name)],
#             'AGE': [MessageHandler(Filters.text & ~Filters.command, age)],
#             'GENDER': [MessageHandler(Filters.text & ~Filters.command, gender)],
#             'GEOLOCATION': [MessageHandler(Filters.location & ~Filters.command, geolocation)],

# def geolocation(update, context):
#     latitude = update.message.location.latitude
#     longitude = update.message.location.longitude
#     address = get_location_name(latitude, longitude)
#     context.user_data['latitude'] = latitude
#     context.user_data['longitude'] = longitude
#     context.user_data['address'] = address
#
#     conn = sqlite3.connect('users.db')
#     c = conn.cursor()
#     c.execute("INSERT INTO users VALUES (?,?,?,?,?,?,?,?)", (
#         context.user_data['phone_number'],
#         context.user_data['first_name'],
#         context.user_data['last_name'],
#         context.user_data['age'],
#         context.user_data['gender'],
#         context.user_data['address'],
#         context.user_data['latitude'],
#         context.user_data['longitude'],
#     )
#               )
#     conn.commit()
#     conn.close()
#     logging.info("User Registered")
#     update.message.reply_text("Ro'yxatdan o'tganingiz uchun Rahmat!")
#     update.message.reply_text(f"""
#         phone: {context.user_data['phone_number']},
#         first_name: {context.user_data['first_name']},
#         last_name: {context.user_data['last_name']},
#         age: {context.user_data['age']},
#         gender: {context.user_data['gender']},
#         address: {context.user_data['address']},
#         """)
#     return ConversationHandler.END
#
#
# def cancel(update, context):
#     update.message.reply_text(text='Bekor qilindi!')
#     return ConversationHandler.END
#
#
# def main():
#     updater = Updater(token="6255255483:AAEGa_tglVQJK74IcUEGCOsfZkEoVzz74dI")
#     dispatcher = updater.dispatcher
#
#     conv_handler = ConversationHandler(
#         entry_points=[CommandHandler('start', start)],
#
#         states={
#             'PHONE_NUMBER': [MessageHandler(Filters.contact & ~Filters.command, phone_number)],
#             'FIRST_NAME': [MessageHandler(Filters.text & ~Filters.command, first_name)],
#             'LAST_NAME': [MessageHandler(Filters.text & ~Filters.command, last_name)],
#             'AGE': [MessageHandler(Filters.text & ~Filters.command, age)],
#             'GENDER': [MessageHandler(Filters.text & ~Filters.command, gender)],
#             'GEOLOCATION': [MessageHandler(Filters.location & ~Filters.command, geolocation)],
#
#         },
#         fallbacks=[CommandHandler('cancel', cancel)]
#     )
#     dispatcher.add_handler(conv_handler)
#     updater.start_polling()
#
#
# if __name__ == '__main__':
#     main()