# Dars - 40 Xasanboeva Nigina

# WELCOME_TEXT = "Xush kelibsiz / Добро пожаловать!"
# CHOOSE_LANG = "Tilni tanlang / Выберите язык!"
# BTN_LANG_UZ = "Uzbek tili"
# BTN_LANG_RU = "Русский язык"
# STATES = {
#     "reg": 1,
#     "menu": 2
# }
# LANGUAGE_CODE = {
#     1: "uz",
#     2: "ru"
# }
# TEXT_LANG_WARNING = "Iltimos tillardan birini tanlang!\nПожалуйста, выберите один из языков!"
# TEXT_ENTER_FIRST_NAME = {
#     1: "Iltimos ismingizni kiriting!",
#     2: "Пожалуйста, введите ваше имя!"
# }
# TEXT_ENTER_LAST_NAME = {
#     1: "Iltimos familiyangizni kiriting!",
#     2: "Пожалуйста, введите свою фамилию!"
# }
# BTN_SEND_CONTACT = {
#     1: "Yuborish",
#     2: "Отправить"
# }
# TEXT_ENTER_CONTACT = {
#     1: "Iltimos telefon raqamingizni yuboring yoki <<Yuborish>> tugmasini bosing!",
#     2: "Отправьте свой номер телефона или нажмите кнопку <<Отправить>>!"
# }
# TEXT_MAIN_MENU = {
#     1: "🏠 Asosiy menyu",
#     2: "🏠 Главное меню"
# }
# BTN_ORDER = {
#     1:"🛒 Buyurtma qilish",
#     2:"🛒 Заказать"
# }
# TEXT_ORDER = {
#     1: "Kategoriylardan birini tanlang!",
#     2: "Выбери одну из категорий!"
# }
# BTN_MY_ORDERS = {
#     1:"🛍 Buyurtmalarim",
#     2:"🛍 Мои заказы"
# }
# BTN_EVOS_FAMILY = {
#     1:"👨‍👩‍👦 EVOS Oilasi",
#     2:"👨‍👩‍👦 Семья EVOS"
# }
# BTN_COMMENTS = {
#     1:"✍️Fikr bildirish",
#     2:"✍️комментарий"
# }
# BTN_SETTINGS = {
#     1:"⚙️Sozlamalar",
#     2:"⚙️Настройки"
# }
#
# ########## new ###########
# TEXT_PRODUCT_PRICE = {
#     1: "Narx:",
#     2: "Цена:"
# }
# TEXT_PRODUCT_DESC = {
#     1: "Tarkibi:",
#     2: "Состав:"
# }
# ###########################
#
# from telegram import KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove
# from database import Database
# import globals
# import methods
# db = Database("db-evos.db")
#
#
# def check(update, context):
#     user = update.message.from_user
#     db_user = db.get_user_by_chat_id(user.id)
#
#     if not db_user:
#         db.create_user(user.id)
#         buttons = [
#             [KeyboardButton(text=globals.BTN_LANG_UZ), KeyboardButton(text=globals.BTN_LANG_RU)]
#         ]
#         update.message.reply_text(text=globals.WELCOME_TEXT)
#         update.message.reply_text(
#             text=globals.CHOOSE_LANG,
#             reply_markup=ReplyKeyboardMarkup(
#                 keyboard=buttons,
#                 resize_keyboard=True
#             )
#         )
#         context.user_data["state"] = globals.STATES["reg"]
#
#     elif not db_user["lang_id"]:
#         buttons = [
#             [KeyboardButton(text=globals.BTN_LANG_UZ), KeyboardButton(text=globals.BTN_LANG_RU)]
#         ]
#         update.message.reply_text(
#             text=globals.CHOOSE_LANG,
#             reply_markup=ReplyKeyboardMarkup(
#                 keyboard=buttons,
#                 resize_keyboard=True
#             )
#         )
#         context.user_data["state"] = globals.STATES["reg"]
#
#     elif not db_user["first_name"]:
#         update.message.reply_text(
#             text=globals.TEXT_ENTER_FIRST_NAME[db_user['lang_id']],
#             reply_markup=ReplyKeyboardRemove()
#         )
#         context.user_data["state"] = globals.STATES["reg"]
#
#     elif not db_user["last_name"]:
#         update.message.reply_text(
#             text=globals.TEXT_ENTER_LAST_NAME[db_user['lang_id']],
#             reply_markup=ReplyKeyboardRemove()
#         )
#         context.user_data["state"] = globals.STATES["reg"]
#
#     elif not db_user["phone_number"]:
#         buttons = [
#             [KeyboardButton(text=globals.BTN_SEND_CONTACT[db_user['lang_id']], request_contact=True)]
#         ]
#         update.message.reply_text(
#             text=globals.TEXT_ENTER_CONTACT[db_user['lang_id']],
#             reply_markup=ReplyKeyboardMarkup(
#                 keyboard=buttons,
#                 resize_keyboard=True
#             )
#         )
#         context.user_data["state"] = globals.STATES["reg"]
#
#     else:
#
#         methods.send_main_menu(context, user.id, db_user['lang_id'])
#         context.user_data["state"] = globals.STATES["menu"]
#
#
# def check_data_decorator(func):
#     def inner(update, context):
#         user = update.message.from_user
#         db_user = db.get_user_by_chat_id(user.id)
#         state = context.user_data.get("state", 0)
#
#         if state != globals.STATES['reg']:
#
#             if not db_user:
#                 db.create_user(user.id)
#                 buttons = [
#                     [KeyboardButton(text=globals.BTN_LANG_UZ), KeyboardButton(text=globals.BTN_LANG_RU)]
#                 ]
#                 update.message.reply_text(text=globals.WELCOME_TEXT)
#                 update.message.reply_text(
#                     text=globals.CHOOSE_LANG,
#                     reply_markup=ReplyKeyboardMarkup(
#                         keyboard=buttons,
#                         resize_keyboard=True
#                     )
#                 )
#                 context.user_data["state"] = globals.STATES["reg"]
#
#             elif not db_user["lang_id"]:
#                 buttons = [
#                     [KeyboardButton(text=globals.BTN_LANG_UZ), KeyboardButton(text=globals.BTN_LANG_RU)]
#                 ]
#                 update.message.reply_text(
#                     text=globals.CHOOSE_LANG,
#                     reply_markup=ReplyKeyboardMarkup(
#                         keyboard=buttons,
#                         resize_keyboard=True
#                     )
#                 )
#                 context.user_data["state"] = globals.STATES["reg"]
#
#             elif not db_user["first_name"]:
#                 update.message.reply_text(
#                     text=globals.TEXT_ENTER_FIRST_NAME[db_user['lang_id']],
#                     reply_markup=ReplyKeyboardRemove()
#                 )
#                 context.user_data["state"] = globals.STATES["reg"]
#
#             elif not db_user["last_name"]:
#                 update.message.reply_text(
#                     text=globals.TEXT_ENTER_LAST_NAME[db_user['lang_id']],
#                     reply_markup=ReplyKeyboardRemove()
#                 )
#                 context.user_data["state"] = globals.STATES["reg"]
#
#             elif not db_user["phone_number"]:
#                 buttons = [
#                     [KeyboardButton(text=globals.BTN_SEND_CONTACT[db_user['lang_id']], request_contact=True)]
#                 ]
#                 update.message.reply_text(
#                     text=globals.TEXT_ENTER_CONTACT[db_user['lang_id']],
#                     reply_markup=ReplyKeyboardMarkup(
#                         keyboard=buttons,
#                         resize_keyboard=True
#                     )
#                 )
#                 context.user_data["state"] = globals.STATES["reg"]
#
#             else:
#                 return func(update, context)
#
#             return False
#
#         else:
#             return func(update, context)
#     return inner
# import sqlite3
#
#
# class Database:
#     def __init__(self, db_name):
#         self.conn = sqlite3.connect(db_name, check_same_thread=False)
#         self.cur = self.conn.cursor()
#
#     def create_user(self, chat_id):
#         self.cur.execute("""insert into user(chat_id) values (?)""", (chat_id,))
#         self.conn.commit()
#
#     def update_user_data(self, chat_id, key, value):
#         self.cur.execute(f"""update user set {key} = ? where chat_id = ?""", (value, chat_id))
#         self.conn.commit()
#
#     def get_user_by_chat_id(self, chat_id):
#         self.cur.execute("""select * from user where chat_id = ?""", (chat_id, ))
#         user = dict_fetchone(self.cur)
#         return user
#
#     def get_categories_by_parent(self, parent_id=None):
#         if parent_id:
#             self.cur.execute("""select * from category where parent_id = ?""", (parent_id, ))
#         else:
#             self.cur.execute("""select * from category where parent_id is NULL""")
#
#         categories = dict_fetchall(self.cur)
#         return categories
#
#     def get_category_parent(self, category_id):
#         self.cur.execute("""select parent_id from category where id = ?""", (category_id, ))
#         category = dict_fetchone(self.cur)
#         return category
#
# ######### new ##############
#     def get_products_by_category(self, category_id):
#         self.cur.execute("""select * from product where category_id = ?""", (category_id, ))
#         products = dict_fetchall(self.cur)
#         return products
#
#     def get_product_by_id(self, product_id):
#         self.cur.execute("""select * from product where id = ?""", (product_id, ))
#         product = dict_fetchone(self.cur)
#         return product
# ##################################
#
#
# def dict_fetchall(cursor):
#     columns = [col[0] for col in cursor.description]
#     return [
#         dict(zip(columns, row))
#         for row in cursor.fetchall()
#     ]
#
#
# def dict_fetchone(cursor):
#     row = cursor.fetchone()
#     if row is None:
#         return False
#     columns = [col[0] for col in cursor.description]
#     return dict(zip(columns, row))

# from telegram import KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardButton
# import globals
#
#
# def send_main_menu(context, chat_id, lang_id, message_id=None):
#     buttons = [
#         [KeyboardButton(text=globals.BTN_ORDER[lang_id])],
#         [KeyboardButton(text=globals.BTN_MY_ORDERS[lang_id]), KeyboardButton(text=globals.BTN_EVOS_FAMILY[lang_id])],
#         [KeyboardButton(text=globals.BTN_COMMENTS[lang_id]), KeyboardButton(text=globals.BTN_SETTINGS[lang_id])]
#     ]
#     if message_id:
#         context.bot.edit_message_text(
#             chat_id=chat_id,
#             message_id=message_id,
#             text=globals.TEXT_MAIN_MENU[lang_id],
#             reply_markup=ReplyKeyboardMarkup(
#                 keyboard=buttons,
#                 resize_keyboard=True
#             )
#         )
#     else:
#         context.bot.send_message(
#             chat_id=chat_id,
#             text=globals.TEXT_MAIN_MENU[lang_id],
#             reply_markup=ReplyKeyboardMarkup(
#                 keyboard=buttons,
#                 resize_keyboard=True
#             )
#         )
#
# ######### lesson-3 ############
# def send_category_buttons(categories, lang_id):
#     buttons = []
#     row = []
#     for i in range(len(categories)):
#         row.append(
#             InlineKeyboardButton(
#                 text=categories[i][f'name_{globals.LANGUAGE_CODE[lang_id]}'],
#                 callback_data=f"category_{categories[i]['id']}"
#             )
#         )
#
#         if len(row) == 2 or (len(categories) % 2 == 1 and i == len(categories) - 1):
#             buttons.append(row)
#             row = []
#     return buttons
#
#
# def send_product_buttons(products, lang_id):
#     buttons = []
#     row = []
#     for i in range(len(products)):
#         row.append(
#             InlineKeyboardButton(
#                 text=products[i][f'name_{globals.LANGUAGE_CODE[lang_id]}'],
#                 callback_data=f"category_product_{products[i]['id']}"
#             )
#         )
#
#         if len(row) == 2 or (len(products) % 2 == 1 and i == len(products) - 1):
#             buttons.append(row)
#             row = []
#
#     return buttons
# ###############################
#
#
