from django.shortcuts import render
from .models import Countries,Employees, Location,
from django.http import HttpResponse
from django.db.models import Q, Count


# Create your views here.


def orm_list(request):
    queryset = Employees.objects.values("job").annotate(xodim_soni=Count("*"))
    for i in queryset:
        print(i.job_id, i.xodim_soni)
    return HttpResponse("ok")
    # e = Empoloyees.objects.getid=1)
    # e.update(
    #     first_name="John"
    # # )
    # # # emp_list = ""
    # # # for c in queryse    #t:
    #     emp_list += f"<li>{c.first_name} {c.last_name}</li>"
    # return HttpResponse(f"<ol>{emp_list}</ol>")
