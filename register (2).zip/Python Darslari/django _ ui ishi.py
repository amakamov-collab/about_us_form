# . App yaratish
# Terminalda:
#
# python manage.py startapp mybooks
#
#  2.models.py (oddiy Kitob modeli)
#
# mybooks/models.py:
#
# from django.db import models
#
# class Book(models.Model):
#     title = models.CharField(max_length=200)
#     description = models.TextField()
#
#     def __str__(self):
#         return self.title
#
#
# Migratsiya qilib qo‘yish:
#
# python manage.py makemigrations
# python manage.py migrate
#
#  3. views.py
#
# mybooks/views.py:
#
# from django.shortcuts import render, get_object_or_404
# from .models import Book
#
# def book_list(request):
#     books = Book.objects.all()
#     return render(request, "book_list.html", {"books": books})
#
# def book_detail(request, pk): 
#     book = get_object_or_404(Book, pk=pk)
#     return render(request, "book_detail.html", {"book": book})
#
#  4. urls.py
#
# Agar project urls.py ichida app’ni ulamagan bo‘lsangiz:
#
# project/urls.py:
#
# from django.contrib import admin
# from django.urls import path, include
#
# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('', include('mybooks.urls')),
# ]
#
#
# Endi appning urls.py faylini yarating:
#
# mybooks/urls.py:
#
# from django.urls import path
# from . import views
#
# urlpatterns = [
#     path('', views.book_list, name="book_list"),
#     path('book/<int:pk>/', views.book_detail, name="book_detail"),
# ]
#
#  5. Templates yaratish
#
#  mybooks/templates/book_list.html:
#
# <h1>Kitoblar ro‘yxati</h1>
#
# <ul>
#   {% for book in books %}
#     <li>
#       <a href="{% url 'book_detail' book.pk %}">
#         {{ book.title }}
#       </a>
#     </li>
#   {% endfor %}
# </ul>
#
#
# mybooks/templates/book_detail.html:
#
# <h2>{{ book.title }}</h2>
#
# <p>{{ book.description }}</p>
#
# <a href="{% url 'book_list' %}">Ortga</a>
#
#  6. Test qilish
#
# Serverni yoqing:
#
# python manage.py runserver
#
#
# http://127.0.0.1:8000/ ga kiring — kitoblar listi
# Kitob ustiga bossangiz — kitob detail ochiladi
# Pastda "Ortga" → listga qaytaradi


