# dars_39 Xasanboeva Nigina
# WELCOME_TEXT = "Xush kelibsiz / Добро пожаловать!"
# CHOOSE_LANG = "Tilni tanlang / Выберите язык!"
# BTN_LANG_UZ = "Uzbek tili"
# BTN_LANG_RU = "Русский язык"
# STATES = {
#     "reg": 1,
#     "menu": 2
# }
# LANGUAGE_CODE = {
#     1: "uz",
#     2: "ru"
# }
# TEXT_LANG_WARNING = "Iltimos tillardan birini tanlang!\nПожалуйста, выберите один из языков!"
# TEXT_ENTER_FIRST_NAME = {
#     1: "Iltimos ismingizni kiriting!",
#     2: "Пожалуйста, введите ваше имя!"
# }
# TEXT_ENTER_LAST_NAME = {
#     1: "Iltimos familiyangizni kiriting!",
#     2: "Пожалуйста, введите свою фамилию!"
# }
# BTN_SEND_CONTACT = {
#     1: "Yuborish",
#     2: "Отправить"
# }
# TEXT_ENTER_CONTACT = {
#     1: "Iltimos telefon raqamingizni yuboring yoki <<Yuborish>> tugmasini bosing!",
#     2: "Отправьте свой номер телефона или нажмите кнопку <<Отправить>>!"
# }
# TEXT_MAIN_MENU = {
#     1: "🏠 Asosiy menyu",
#     2: "🏠 Главное меню"
# }
# BTN_ORDER = {
#     1:"🛒 Buyurtma qilish",
#     2:"🛒 Заказать"
# }
# TEXT_ORDER = {
#     1: "Kategoriylardan birini tanlang!",
#     2: "Выбери одну из категорий!"
# }
# BTN_MY_ORDERS = {
#     1:"🛍 Buyurtmalarim",
#     2:"🛍 Мои заказы"
# }
# BTN_EVOS_FAMILY = {
#     1:"👨‍👩‍👦 EVOS Oilasi",
#     2:"👨‍👩‍👦 Семья EVOS"
# }
# BTN_COMMENTS = {
#     1:"✍️Fikr bildirish",
#     2:"✍️комментарий"
# }
# BTN_SETTINGS = {
#     1:"⚙️Sozlamalar",
#     2:"⚙️Настройки"
# }
#
# import sqlite3
#
#
# class Database:
#     def __init__(self, db_name):
#         self.conn = sqlite3.connect(db_name, check_same_thread=False)
#         self.cur = self.conn.cursor()
#
#     def create_user(self, chat_id):
#         self.cur.execute("""insert into user(chat_id) values (?)""", (chat_id,))
#         self.conn.commit()
#
#     def update_user_data(self, chat_id, key, value):
#         self.cur.execute(f"""update user set {key} = ? where chat_id = ?""", (value, chat_id))
#         self.conn.commit()
#
#     def get_user_by_chat_id(self, chat_id):
#         self.cur.execute("""select * from user where chat_id = ?""", (chat_id, ))
#         user = dict_fetchone(self.cur)
#         return user
#
#     def get_categories_by_parent(self, parent_id=None):
#         if parent_id:
#             self.cur.execute("""select * from category where parent_id = ?""", (parent_id, ))
#         else:
#             self.cur.execute("""select * from category where parent_id is NULL""")
#
#         categories = dict_fetchall(self.cur)
#         return categories
#
#     def get_category_parent(self, category_id):
#         self.cur.execute("""select parent_id from category where id = ?""", (category_id, ))
#         category = dict_fetchone(self.cur)
#         return category
#
#
# def dict_fetchall(cursor):
#     columns = [col[0] for col in cursor.description]
#     return [
#         dict(zip(columns, row))
#         for row in cursor.fetchall()
#     ]
#
#
# def dict_fetchone(cursor):
#     row = cursor.fetchone()
#     if row is None:
#         return False
#     columns = [col[0] for col in cursor.description]
#     return dict(zip(columns, row))
#
#
# from telegram import InlineKeyboardButton, InlineKeyboardMarkup
# from database import Database
# import globals
#
# db = Database("db-evos.db")
#
# ##### Lesson-2 ###############
# def inline_handler(update, context):
#
#     query = update.callback_query
#     data_sp = str(query.data).split("_")
#     db_user = db.get_user_by_chat_id(query.message.chat_id)
#
#     if data_sp[0] == "category":
#         if data_sp[1] == "back":
#             if len(data_sp) == 3:
#                 parent_id = int(data_sp[2])
#             else:
#                 print("No parent")
#                 parent_id = None
#
#             categories = db.get_categories_by_parent(parent_id=parent_id)
#             buttons = []
#             row = []
#             for i in range(len(categories)):
#                 row.append(
#                     InlineKeyboardButton(
#                         text=categories[i][f'name_{globals.LANGUAGE_CODE[db_user["lang_id"]]}'],
#                         callback_data=f"category_{categories[i]['id']}"
#                     )
#                 )
#
#                 if len(row) == 2 or (len(categories) % 2 == 1 and i == len(categories) - 1):
#                     buttons.append(row)
#                     row = []
#
#             if parent_id:
#                 clicked_btn = db.get_category_parent(parent_id)
#
#                 if clicked_btn and clicked_btn['parent_id']:
#                     buttons.append([InlineKeyboardButton(
#                         text="Back", callback_data=f"category_back_{clicked_btn['parent_id']}"
#                     )])
#                 else:
#                     buttons.append([InlineKeyboardButton(
#                         text="Back", callback_data=f"category_back"
#                     )])
#
#             query.message.edit_reply_markup(
#                 reply_markup=InlineKeyboardMarkup(
#                     inline_keyboard=buttons
#                 )
#             )
#         else:
#             categories = db.get_categories_by_parent(parent_id=int(data_sp[1]))
#             buttons = []
#             row = []
#             for i in range(len(categories)):
#                 row.append(
#                     InlineKeyboardButton(
#                         text=categories[i][f'name_{globals.LANGUAGE_CODE[db_user["lang_id"]]}'],
#                         callback_data=f"category_{categories[i]['id']}"
#                     )
#                 )
#
#                 if len(row) == 2 or (len(categories) % 2 == 1 and i == len(categories) - 1):
#                     buttons.append(row)
#                     row = []
#
#             clicked_btn = db.get_category_parent(int(data_sp[1]))
#
#             if clicked_btn and clicked_btn['parent_id']:
#                 buttons.append([InlineKeyboardButton(
#                     text="Back", callback_data=f"category_back_{clicked_btn['parent_id']}"
#                 )])
#             else:
#                 buttons.append([InlineKeyboardButton(
#                     text="Back", callback_data=f"category_back"
#                 )])
#
#             query.message.edit_reply_markup(
#                 reply_markup=InlineKeyboardMarkup(
#                     inline_keyboard=buttons
#                 )
#             )
################################



